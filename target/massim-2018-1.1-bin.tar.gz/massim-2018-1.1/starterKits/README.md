# MAPC Starter Kits

Here we gather packages that may help people get started using a(n agent)
framework in no time by removing the effort of establishing the connection to
the MAPC server.

If you are looking for a way to connect your Java platform, you might want to
have a look at [EISMASSim](../docs/eismassim.md).

If you have such a _starter kit_ for a framework or language that is missing
here and you want to share it, we would be happy to include it.
